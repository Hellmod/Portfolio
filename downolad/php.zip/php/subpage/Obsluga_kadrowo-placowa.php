﻿<div id="TopMain">
	<div id="TopHederRightButton"> <a href="index2.php?id=Ksiega_rachunkowa">Księga rachunkowa</a></div>	
	<div id="TopHederRightButton"> <a href="index2.php?id=Ksiazka_Przychodow_i_rozchodow">Książka Przychodów i rozchodów</a></div>
	<div id="TopHederRightButton"> <a href="index2.php?id=Obsluga_kadrowo-placowa"><div id="select">Obsługa kadrowo-płacowa</div></a></div>
</div>
<h3>Obsługa Kadr i Płac</h3>
<ul>
<li>sporządzanie miesięcznych list płac pracowników zatrudnionych na podstawie umowy o pracę oraz umów cywilnoprawnych,</li>
<li>przygotowywanie zgłoszeń do ubezpieczenia społecznego i zdrowotnego osób zatrudnionych oraz umów cywilnoprawnych,</li>
<li>przygotowywanie miesięcznych zaliczek na podatek dochodowy od osób zatrudnionych przez pracodawcę oraz umów cywilnoprawnych,</li>
<li>bieżące wyliczanie miesięcznych składek oraz sporządzanie deklaracji ZUS i przesyłanie ich w formie elektronicznej do Zakładu Ubezpieczeń </li>Społecznych,
<li>sporządzanie oraz dostarczanie do Urzędów Skarbowych obowiązujących deklaracji i rozliczeń,</li>
<li>sporządzanie deklaracji PFRON,</li>
<li>sporządzanie na koniec roku kalendarzowego: zestawień przesłanych składek na ubezpieczenia społeczne i zdrowotne, rocznych kart wynagrodzeń pracowników, informacji o uzyskanych przez pracowników dochodach oraz pobranych zaliczkach na podatek dochodowy,</li>
<li>sporządzanie deklaracji i rozliczeń przeznaczonych dla pracowników.</li>
</ul>