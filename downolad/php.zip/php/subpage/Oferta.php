﻿<div id="TopMain">
	<div id="TopHederRightButton"> <a href="index2.php?id=Ksiega_rachunkowa">Księga rachunkowa</a></div>	
	<div id="TopHederRightButton"> <a href="index2.php?id=Ksiazka_Przychodow_i_rozchodow">Książka Przychodów i rozchodów</a></div>
	<div id="TopHederRightButton"> <a href="index2.php?id=Obsluga_kadrowo-placowa">Obsługa kadrowo-płacowa</a></div>
</div>


<h3>Oferta</h3>
<table>
<tr>
	<td><a href="index2.php?id=Obsluga_kadrowo-placowa"><img src="graphics/1.jpg" alt="brak obrazka"></img></a></td>
	<td><a href="index2.php?id=Ksiazka_Przychodow_i_rozchodow"><img src="graphics/1.jpg" alt="brak obrazka"></img></a></td>
	<td><a href="index2.php?id=Ksiega_rachunkowa"><img src="graphics/1.jpg" alt="brak obrazka"></img></a></td>
</tr>
<tr>
	<td><a href="index2.php?id=Obsluga_kadrowo-placowa">Obsługa kadrowo-płacowa</a></td>	
	<td><a href="index2.php?id=Ksiazka_Przychodow_i_rozchodow">Książka Przychodów i rozchodów</a></td>
	<td><a href="index2.php?id=Ksiega_rachunkowa">Księga rachunkowa</a></td>
</tr>
</table>

Oferta <b>Biura Rachunkowego VatMar w Krakowie</b> obejmuje swym zakresem obsługę finansowo-księgową i kadrowo-płacową micro, małych i średniej wielkości firm działających w różnych branżach gospodarki.
</br></br>
Współpracujemy z wieloma podmiotami zróżnicowanymi pod względem formy prawnej oraz wielkości. Swoje usługi świadczymy więc spółkom osobowym i kapitałowym, firmom jednoosobowym.
</br></br>
Prowadzimy księgi rachunkowe, księgi przychodów i rozchodów oraz ewidencje stosowane przy rozliczaniu ryczałtu od przychodów ewidencjonowanych.
</br></br>
Swoje usługi księgowe realizujemy dla klientów zlokalizowanych na obszarze całego kraju, głównie jednak na terenie województwa małopolskiego, szczególnie Krakowa i okolic.
</br></br>
Specjalizacją <b>Biura Rachunkowego VatMar w Krakowie</b> jest kompleksowa obsługa finansowo-księgowa oraz kadrowo-płacowa podmiotów gospodarczych prowadzona w ramach umów o stałą współpracę. W zakres usługi kompleksowej, oprócz podstawowych czynności ewidencyjno-rozliczeniowych i sprawozdawczych wchodzi, bez dodatkowych opłat, doradztwo.
