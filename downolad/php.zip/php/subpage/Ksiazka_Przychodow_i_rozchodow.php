﻿<div id="TopMain">
	<div id="TopHederRightButton"> <a href="index2.php?id=Ksiega_rachunkowa">Księga rachunkowa</a></div>	
	<div id="TopHederRightButton"> <a href="index2.php?id=Ksiazka_Przychodow_i_rozchodow"><div id="select">Książka Przychodów i rozchodów</div></a></div>
	<div id="TopHederRightButton"> <a href="index2.php?id=Obsluga_kadrowo-placowa">Obsługa kadrowo-płacowa</a></div>
</div>
<h3>Księgi Przychodów i Rozchodów / Ryczałt od Przychodów Ewidencjonowanych</h3>
<ul>
<li>bieżący zapis dokumentów w księdze przychodów i rozchodów, ewidencji przychodów (ryczałt) oraz w rejestrach VAT,</li>
<li>prowadzenie rejestrów sprzedaży i zakupów VAT,</li>
<li>przygotowywanie miesięcznych rozliczeń podatku dochodowego PIT, podatku od towarów i usług VAT,</li>
<li>zakładanie i prowadzenie ewidencji majątku trwałego i wyposażenia,</li>
<li>sporządzanie deklaracji i przesyłanie ich w formie elektronicznej do Urzędów Skarbowych, ZUS,</li>
<li>wykonywanie rocznych rozliczeń, informacji i raportów dla Urzędów Skarbowych, Zakładu Ubezpieczeń Społecznych i Urzędu Statystycznego,</li>
<li>sporządzanie rocznych zeznań podatkowych przedsiębiorców,</li>
</ul>