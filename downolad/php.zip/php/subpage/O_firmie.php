﻿<div id="TopMain">
</div>
<font size="5"><b><i>VATMAR BIURO RACHUNKOWE: </i></b></font>
<b><i>księgowość i doradztwo podatkowe</i></b>
</br>
<pre>
Jesteśmy licencjonowanym biurem rachunkowym działającym na podstawie świadectwa
kwalifikacji Ministerstwa Finansów nr 23462/2008 oferującym pełen zakres usług na terenie
Krakowa i okolic.
Zapewniamy profesjonalną obsługę księgową oraz kadrową podmiotów gospodarczych o różnych
formach prawnych i profilach działalności. Cechuje nas zaangażowanie, rzetelność,
profesjonalizm i terminowość tak ważna w tej działalności. Jesteśmy firmą nastawioną na
potrzeby Klienta, dlatego staramy się zapewnić takie warunki współpracy, które pozwolą
przedsiębiorcom skoncentrować się na dynamicznym rozwoju własnych firm.
Nasze biuro działające od 2008 ­ dzięki wieloletniemu doświadczeniu jest w stanie
zagwarantować naszym Klientom usługi na najwyższym poziomie, a bezpieczeństwo zapewnia
odpowiednie ubezpieczenie od odpowiedzialności cywilnej.
</pre>
		<ul>
			Zakres obsługi księgowej Biura Rachunkowego Vatmar
			<li>prowadzenie książki przychodów i rozchodów (KPIR)</li>
			<li>prowadzenie ksiąg handlowych (pełna księgowość)</li>
			<li>ryczałt ewidencjonowany</li>
			<li>prowadzenie kadr i płac</li>
			<li>konsultacje dla osób pragnących założyć działalność gosp.</li>
			<li>porady w kwesiach związanych z prowadzoną działalnością gosp.</li>
		</ul>