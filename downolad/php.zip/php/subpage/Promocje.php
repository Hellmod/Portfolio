﻿<div id="TopMain">
</div>
<h3>Promocje</h3>

"<b>Bonus na start</b>" -wszystkim klientom, którzy zawierają umowę z biurem rachunkowym VatMar, o regularne świadczenie usług księgowych, oferujemy obniżkę ceny na okres trzech pierwszych miesięcy współpracy, w wysokości  40% uzgodnionej ceny umownej.</br> 
"<b>Podaj dalej</b>" - każdy z naszych Klientów, który poleci nas swoim znajomym i dojdzie do podpisania umowy, otrzyma bonifikatę w wysokości jednomiesięcznej wartości swojej opłaty (dotyczy klientów KPiR).	</br>
"<b>Niższe koszty</b>" - przy przejściu z innego Biura – koszt obsługi niższy o 20 %.</br></br></br>
