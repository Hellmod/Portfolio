﻿<div id="TopMain">
	<div id="TopHederRightButton"> <a href="index2.php?id=Ksiega_rachunkowa"><div id="select">Księga rachunkowa</div></a></div>	
	<div id="TopHederRightButton"> <a href="index2.php?id=Ksiazka_Przychodow_i_rozchodow">Książka Przychodów i rozchodów</a></div>
	<div id="TopHederRightButton"> <a href="index2.php?id=Obsluga_kadrowo-placowa">Obsługa kadrowo-płacowa</a></div>
</div>
<h3>Księgi Rachunkowe</h3>
<ul>
<li>	otwarcie ksiąg rachunkowych na dzień rozpoczęcia działalności,</li>
<li>	opracowanie zakładowego planu kont oraz polityki rachunkowości,</li>
<li>	bieżący zapis dokumentów w księdze handlowej oraz rejestrach podatku od towarów i usług,</li>
<li>	prowadzenie rejestrów sprzedaży i zakupów VAT,</li>
<li>	przygotowywanie miesięcznych rozliczeń podatku dochodowego CIT, podatku od towarów i usług VAT,</li>
<li>	zakładanie i prowadzenie ewidencji środków trwałych oraz naliczanie odpisów amortyzacyjnych,</li>
<li>	sporządzanie sprawozdań statystycznych wymaganych przez Główny Urząd Statystyczny,</li>
<li>	przeprowadzanie uzgodnień sald należności i zobowiązań,</li>
<li>	zamknięcie roku obrotowego, sporządzenie sprawozdania finansowego – w tym: bilansu, rachunku zysków i strat, cash flow oraz informacji dodatkowej,</li>
<li>	sporządzanie zeznania o wysokości osiągniętego rocznego dochodu CIT-8,</li>
<li> pomoc przy formułowaniu uchwał oraz przygotowywaniu dokumentów sprawozdawczych do KRS i Urzędu Skarbowego.</li>
</ul>