package Game;

import java.awt.Graphics;

public abstract class Monster {

	abstract void update();
	
	abstract void render(Graphics g);

	
	

}
